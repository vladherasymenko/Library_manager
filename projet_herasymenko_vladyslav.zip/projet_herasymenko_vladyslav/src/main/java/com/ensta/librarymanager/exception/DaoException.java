package com.ensta.librarymanager.exception;

public class DaoException extends Exception{

}
