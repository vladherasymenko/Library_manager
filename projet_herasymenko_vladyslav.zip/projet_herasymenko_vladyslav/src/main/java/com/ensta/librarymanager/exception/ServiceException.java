package com.ensta.librarymanager.exception;

public class ServiceException extends Exception {

}
